# OCR > new_dataset_v1
https://universe.roboflow.com/kalpesh-guztn/ocr-vgcdv

Provided by a Roboflow user
License: CC BY 4.0

